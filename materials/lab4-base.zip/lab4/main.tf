terraform {
  required_providers {
    google = {
      source  = "hashicorp/google"
      version = "~> 6.0"
    }
  }
}

provider "google" {
  project = var.project
  zone    = var.zone
}

variable "project" {
  type = string
  default = "MYPROJECTID" # replace with project id!
}
variable "zone" {
  type    = string
  default = "us-central1-a"
}

data "google_compute_image" "base" {
  family  = "ubuntu-2404-lts-amd64"
  project = "ubuntu-os-cloud"
}

resource "google_storage_bucket" "data" {
  name                        = "${var.project}-lab4-bucket"
  location                    = "US"
  uniform_bucket_level_access = true
  force_destroy               = true
  labels                      = { course = "adpd" }
}

resource "google_compute_disk" "extra" {
  name   = "lab4-disk"
  size   = 10
  type   = "pd-balanced"
  labels = { course = "adpd" }
}

resource "google_compute_instance" "lab" {
  name         = "lab4-vm"
  machine_type = "e2-medium"

  boot_disk {
    initialize_params { image = data.google_compute_image.base.self_link }
  }

  attached_disk {
    source      = google_compute_disk.extra.id
    device_name = "extra"
  }

  network_interface {
    network = "default"
    access_config {}
  }

  metadata_startup_script = file("${path.module}/startup.sh")

  service_account {
    scopes = ["cloud-platform"]
  }

  scheduling {
    max_run_duration { seconds = 14400 }
    instance_termination_action = "DELETE"
  }

  labels = { course = "adpd" }
}

