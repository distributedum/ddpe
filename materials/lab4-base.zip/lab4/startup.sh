#!/bin/bash
set -eux
apt-get update -y
apt-get install -y unzip curl python micro
